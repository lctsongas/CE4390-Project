/*
 * serialRead.c
 *
 *  Created on: Apr 26, 2017
 *      Author: chris
 */

#include "serialRead.h"

unsigned int disp1,disp2,disp3,disp4;

unsigned long getKey(){
	unsigned long key;
	serialRead();
	key = ((unsigned long)disp1*0x1000) | ((unsigned long)disp2*0x100) | ((unsigned long)disp3*0x10) | (unsigned long)disp4;

	return key;
}

unsigned int seg7ToBCD(unsigned int displayValue){
	switch(displayValue){
	case 0x3F:  //zero displayed
		return 0;
	case 0x06:  //one displayed
		return 1;
	case 0x5B:  //two displayed
		return 2;
	case 0x4F:  //three displayed
		return 3;
	case 0x66:  //four displayed
		return 4;
	case 0x6D:  //five displayed
		return 5;
	case 0x7D:  //six displayed
		return 6;
	case 0x07:  //seven displayed
		return 7;
	case 0x7F:  //eight displayed
		return 8;
	case 0x6F:  //nine displayed
		return 9;
	default:
		return 0xE;
	}
}

void serialRead(){
    serialSetup();  //reset serial connection
    //__disable_interrupt();  //stop interrupts while serial is being read
    SERIAL_PORT_OUT |= SERIAL_SHLD;  //set SH/~LD to high (stop input)
    unsigned int dispValue = 0;
    unsigned int readIn = 0;
    unsigned int BCDValue = 0;
    unsigned int currentBit = 1;
    while(currentBit <= 32){
           SERIAL_PORT_OUT |= SERIAL_CLK;  //set clock high
           __delay_cycles(50000);  //send update to shift registers

           //P4REN |= BIT6;  //enable P4.6 PuP
           SERIAL_PORT_OUT &= ~(SERIAL_CLK);  //set clock low
           if(currentBit % 8 == 0){
               BCDValue = seg7ToBCD(dispValue);  //convert display to BCD
               if(disp1 == 0xF){
                   disp1 = BCDValue;
               }else if(disp2 == 0xF){
                   disp2 = BCDValue;
               }else if(disp3 == 0xF){
                   disp3 = BCDValue;
               }else if(disp4 == 0xF){
                   disp4 = BCDValue;
               }
               dispValue = 0;
               readIn = 0;
               BCDValue = 0;
           }else{
               //read in single segment
               readIn = SERIAL_PORT_IN & SERIAL_IN;  //read next serial bit
               if(readIn)
                   dispValue = (dispValue << 1) | 1;  //1 read in
               else
                   dispValue = (dispValue << 1);  //0 read in
           }
           currentBit+=1;
    }
    SERIAL_PORT_OUT &= ~(SERIAL_SHLD);  //set SH/~LD to high (stop input)
    //__enable_interrupt();  //reenable interrupts now that serial is done

}

void serialSetup(){
	SERIAL_PORT_REN |= SERIAL_IN;  //enable pullup R for I/P
	SERIAL_PORT_DIR |= (SERIAL_SHLD | SERIAL_CLK);  //make outputs (SH/~LD) and CLK
	SERIAL_PORT_OUT &= ~(SERIAL_SHLD | SERIAL_CLK);  //set CLK and SH/~LD to 0
	SERIAL_PORT_DIR &= ~(SERIAL_IN);  //make input (Serial In)
	disp1=0xF;  //set BCD values to large number for debugging
	disp2=0xF;
	disp3=0xF;
	disp4=0xF;
}
