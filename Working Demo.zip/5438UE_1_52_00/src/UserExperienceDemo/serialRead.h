#include <msp430.h>

#ifndef SERIALREAD_H
#define SERIALREAD_H

#define PARALLEL_BYTES 4  //sets number of 7-seg displays to read
#define PARALLEL_BITS 8  //sets number of bits per module

#define SERIAL_PORT_OUT P10OUT
#define SERIAL_PORT_DIR P10DIR
#define SERIAL_PORT_REN P10REN
#define SERIAL_PORT_IN P10IN
#define SERIAL_IN BIT7
#define SERIAL_SHLD BIT6
#define SERIAL_CLK BIT5

unsigned int seg7ToBCD(unsigned int displayValue);  //converts given serial data and converts it to a BCD number
void serialRead();  //reads in the data
void serialSetup();  //sets up serial read
unsigned long getKey();  //called by outside class

#endif /* SERIALREAD_H */
