/* --COPYRIGHT--,BSD_EX
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *******************************************************************************
 *
 *                       MSP430 CODE EXAMPLE DISCLAIMER
 *
Q:How many iterations needed to calculate π with 3 digits accuracy (i.e. 3.14xxx)?
A: n = 119 iterations

//   Built with CCSv4 and IAR Embedded Workbench Version: 4.21
//******************************************************************************
 */


#include <msp430.h>
#include <stdio.h>
#include "HAL_Dogs102x6.h"
#include "HAL_Buttons.h"

#define BUTTON_PORT_IN    PAIN


void led_status_disp();
void segUpdate();
volatile int number_hex;
volatile int N1,N2,N3,N4;

int main(void)
{


  uint8_t contrast, brightness;
  contrast = 11;
  brightness = 11;

  WDTCTL = WDTPW+WDTHOLD;                   // Stop WDT

  // Configure LED1 and LED2
  P1DIR |= BIT0;
  P8DIR |= BIT1;

  // Configure button ports
  PADIR &= ~0x0480;               // Buttons on P1.7/P2.2 are inputs
  P2DIR &= 0xfb;
  // Configure CapTouch ports
  P1OUT &= ~0x7E;
  P1DIR |= 0x7E;
  P6OUT = 0x00;
  P6DIR = 0x00;

  // Configure Dogs102x6 ports
  P5OUT &= ~(BIT6 + BIT7);        // LCD_C/D, LCD_RST
  P5DIR |= BIT6 + BIT7;
  P7OUT &= ~(BIT4 + BIT6);        // LCD_CS, LCD_BL_EN
  P7DIR |= BIT4 + BIT6;
  P4OUT &= ~(BIT1 + BIT3);        // SIMO, SCK
  P4DIR &= ~BIT2;                 // SOMI pin is input
  P4DIR |= BIT1 + BIT3;

  // Buttons Initialization -> S1 - Interrupt based ; S2 - Polling based
  Buttons_init(BUTTON_ALL);
  Buttons_interruptEnable(BUTTON_S1);
  Buttons_interruptDisable(BUTTON_S2);
  buttonsPressed = 0;

  // LCD initialization
  Dogs102x6_init();
  Dogs102x6_backlightInit();

  // Set Default Contrast
      contrast = 11;

  // Set Default Brightness
      brightness = 11;

  Dogs102x6_setBacklight(brightness);
  Dogs102x6_setContrast(contrast);
  Dogs102x6_clearScreen();
  Dogs102x6_stringDraw(1,1,"BEGIN",DOGS102x6_DRAW_NORMAL);
  //led_status_disp();
  N1 = 10;
  N2 = 10;
  N3 = 10;
  N4 = 10;


  while(1){
      P4REN |= BIT6;  //enable P4.6 PuP
      P4DIR |= (BIT4 | BIT0);  //P4.4 and P4.0 are outputs (SH/~LD) and CLK
      P4OUT &= ~(BIT4);  //P4.4 set to parallel load = 0
      P4OUT &= ~(BIT0);  //4.0 set to 0
      P4DIR &= ~BIT6;  //P4.6 as input (Serial In)
      /*
      //DEBUG
      char bufferL0[30];
      char bufferL1[30];
      char bufferL2[30];
      volatile int run = 0;
      volatile int value = 0;
      while(run < 8){
          volatile int readIn = 0;
          while((BIT2 & P2IN)){  // poll S2 (P2.2) for press

          }
          __delay_cycles(250000);  //delay before clocking
          P4OUT &= (~BIT0);  //set clock low
          P4OUT |= BIT4;  //set SH/~LD to high (stop input)
          readIn = (P4IN & BIT6) >> 6;  //read P4.6 input
          __delay_cycles(100000);  //delay before clocking
          P4OUT |= BIT0;  //set clock high
          value = (value << 1) + readIn;
          sprintf(bufferL0, "Run: %d", run);
          sprintf(bufferL1, "Shift = %d", readIn);
          sprintf(bufferL2, "Value = %x", value);
          Dogs102x6_stringDraw(0,1,(void *)bufferL0,DOGS102x6_DRAW_NORMAL);
          Dogs102x6_stringDraw(1,1,(void *)bufferL1,DOGS102x6_DRAW_NORMAL);
          Dogs102x6_stringDraw(2,1,(void *)bufferL2,DOGS102x6_DRAW_NORMAL);
          run += 1;
      }
      //END DEBUG
      */
      __bis_SR_register(LPM0_bits | GIE); // Enter Low Power Mode 0 + Global Interrupt Enable

      led_status_disp();
  }
}

void led_status_disp()
{
    Dogs102x6_clearScreen();
    //segUpdate();
    char bufferL0[30];
    char bufferL1[30];
    char bufferL2[30];
    char bufferL3[30];
    sprintf(bufferL0, "number = %x", number_hex);
    sprintf(bufferL1, "%d %d %d %d", N1,N2,N3,N4);
    //sprintf(bufferL2, "Est. = %f", 4*pi_est);
    //sprintf(bufferL3, "Err. = %f", pi_err);

    Dogs102x6_stringDraw(0,1,(void *)bufferL0,DOGS102x6_DRAW_NORMAL);

    Dogs102x6_stringDraw(1,1,(void *)bufferL1,DOGS102x6_DRAW_NORMAL);

    //Dogs102x6_stringDraw(2,1,(void *)bufferL2,DOGS102x6_DRAW_NORMAL);

    //Dogs102x6_stringDraw(3,1,(void *)bufferL3,DOGS102x6_DRAW_NORMAL);
}


void segUpdate(){
    volatile int displays = 2;
    volatile int currentDisp = 0;
    P4OUT |= BIT4;  //set SH/~LD to high (stop input)
    while(currentDisp < displays){
        volatile int MAX = 8;
        volatile int clocks = 0;
        volatile int value = 0;
        volatile int readIn = 0;
        P4REN |= BIT6;  //enable P4.6 PuP
        //P4DIR |= (BIT4 | BIT0);  //P4.4 and P4.0 are outputs (SH/~LD) and CLK
        //P4OUT &= ~(BIT4);  //P4.4 set to parallel load = 0
        //P4OUT &= ~(BIT0);  //4.0 set to 0
        //P4DIR &= ~BIT6;  //P4.6 as input (Serial In)
        //load in values before starting
        __delay_cycles(10000);

        while(clocks < MAX){
            P4REN |= BIT6;  //enable P4.6 PuP
            //read in single segment
            readIn = (P4IN & BIT6) >> 6;  //read P4.6 input
            value = (value << 1) + readIn;  //shift value and add new data
            //send update to shift registers
            P4OUT |= BIT0;  //set clock high

            __delay_cycles(100000);  //delay before clocking
            P4REN |= BIT6;  //enable P4.6 PuP
            P4OUT &= (~BIT0);  //set clock low
            clocks += 1;
        }
        switch(value){
        case 0x3F:  //zero displayed
            if(N1 == 10)
                N1 = 0;
            else if(N2 == 10)
                N2 = 0;
            else if(N3 == 10)
                N3 = 0;
            else if(N4 == 10)
                N4 = 0;
            break;
        case 0x30:  //one displayed
            if(N1 == 10)
                N1 = 1;
            else if(N2 == 10)
                N2 = 1;
            else if(N3 == 10)
                N3 = 1;
            else if(N4 == 10)
                N4 = 1;
            break;
        case 0x5B:  //two displayed
            if(N1 == 10)
                N1 = 2;
            else if(N2 == 10)
                N2 = 2;
            else if(N3 == 10)
                N3 = 2;
            else if(N4 == 10)
                N4 = 2;
            break;
        case 0x4F:  //three displayed
            if(N1 == 10)
                N1 = 3;
            else if(N2 == 10)
                N2 = 3;
            else if(N3 == 10)
                N3 = 3;
            else if(N4 == 10)
                N4 = 3;
            break;
        case 0x66:  //four displayed
            if(N1 == 10)
                N1 = 4;
            else if(N2 == 10)
                N2 = 4;
            else if(N3 == 10)
                N3 = 4;
            else if(N4 == 10)
                N4 = 4;
            break;
        case 0x6D:  //five displayed
            if(N1 == 10)
                N1 = 5;
            else if(N2 == 10)
                N2 = 5;
            else if(N3 == 10)
                N3 = 5;
            else if(N4 == 10)
                N4 = 5;
            break;
        case 0x7D:  //six displayed
            if(N1 == 10)
                N1 = 6;
            else if(N2 == 10)
                N2 = 6;
            else if(N3 == 10)
                N3 = 6;
            else if(N4 == 10)
                N4 = 6;
            break;
        case 0x07:  //seven displayed
            if(N1 == 10)
                N1 = 7;
            else if(N2 == 10)
                N2 = 7;
            else if(N3 == 10)
                N3 = 7;
            else if(N4 == 10)
                N4 = 7;
            break;
        case 0x7F:  //eight displayed
            if(N1 == 10)
                N1 = 8;
            else if(N2 == 10)
                N2 = 8;
            else if(N3 == 10)
                N3 = 8;
            else if(N4 == 10)
                N4 = 8;
            break;
        case 0x6F:  //nine displayed
            if(N1 == 10)
                N1 = 9;
            else if(N2 == 10)
                N2 = 9;
            else if(N3 == 10)
                N3 = 9;
            else if(N4 == 10)
                N4 = 9;
            break;
        default:
            if(N1 == 10)
                N1 = 11;
            else if(N2 == 10)
                N2 = 11;
            else if(N3 == 10)
                N3 = 11;
            else if(N4 == 10)
                N4 = 11;
            break;
        }


        currentDisp += 1;
        number_hex = value;
    }
    P4OUT &= ~BIT4;  //set SH/~LD to low (resume input)
    }

